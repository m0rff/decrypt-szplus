# decrypt-sueddeutsche
A Chrome plugin to decrypt SZPlus articles
